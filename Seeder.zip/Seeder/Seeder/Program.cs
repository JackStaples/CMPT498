﻿using System;
using System.Collections;
using System.Data.SqlClient;

namespace Seeder
{
    class Program
    {
        static private SqlConnection Connector;
        static private SqlCommand Command;
        static private SqlDataReader Reader;
        static private string database = "CMPT498";
        static private string table = "rawdata";
        static private string temp = "rawdataYear";// or daytable
        static private string connect = "server=DESKTOP-TOSQMFB; database=" + database + "; trusted_connection=True;";
        static private int[] startDate = { 2016, 01, 01};
        static private int iterations = 365;//days in a year.
        static private int[] vdsIds;
        static private int[] Lanes;
        static private bool KeepOpen = false;
        static private ArrayList General;
        static private ArrayList Dates;
        static private ArrayList results;

        static void setup()
        {
            Connector = new SqlConnection();
            Command = new SqlCommand();
            Connector.ConnectionString = connect;
            Command.Connection = Connector;
            General = new ArrayList();
            Dates = new ArrayList();
            results = new ArrayList();
        }

        static void Main(string[] args)
        {
            setup();
            createfauxWarehouse();
            getAllDays();
            launchLoader();
            wait();
        }

        static void createfauxWarehouse()
        {
            System.Console.WriteLine("Creating '" + temp + "' table...");
            string query = "create table " + temp +
                " ( datetime datetime NOT NULL, vdsId int NOT NULL, " +
                  "lane int NOT NULL, speed int, occ int, vol int);";
           GeneralQuery(query, false);
        }

        static private void getAllDays()
        {
            System.Console.WriteLine("Getting all days in the raw table...");
            string query = "select distinct cast(datetime as date) from " +
                table + " where datetime is not null";
            GeneralQuery(query, true);
            string[] sep = { " " };
            string[] tokens = new string[3];         
            foreach (string str in General)
            {
                tokens = str.Split(sep, StringSplitOptions.None);
                Dates.Add(tokens[0]);
            }
            Console.WriteLine(Dates.Count);
        }

        static void GeneralQuery(string query, bool get)
        {

            General.Clear();
            Command.CommandText = query;
            if (!KeepOpen)
            {
                Connector.Open();
            }
            
            if (get)
            {
                getData();
            }
            else
            {
                Command.ExecuteNonQuery();
            }
            if (!KeepOpen)
            {
                Connector.Close();
            }
            
        }

        static void getData()
        {

                Reader = Command.ExecuteReader();
                while (Reader.Read())
                {
                    string row = "";
                    for (int i = 0; i < Reader.FieldCount; i++)
                    {
                        row += Reader[i].ToString();
                        if (i < Reader.FieldCount - 1)
                        {
                            row += ",";
                        }
                        
                    }
                    General.Add(row);
                }

        }

        static private void wait()
        {
            System.Console.WriteLine("Press Enter To exit.");
            System.Console.Read();
            Environment.Exit(0);
        }

        static private void launchLoader()
        {
            System.Console.WriteLine("Beginning Insertion...");
            Random rand = new Random();
            for (int i = 0; i < iterations; i++)
            {
                makeRows(rand);
                Console.WriteLine("Inserted " + Convert.ToString(i + 1) +
                    " out of " + Convert.ToString(iterations) + " days.");
            }
        }

        static private void makeRows(Random rand)
        {
            string query = "";                
            string datetime = makeDate();
            int num = rand.Next() % Dates.Count;
            query = "select datetime, vdsId, lane, Speed, Occupancy, Volume from " + table +
                " where cast(datetime as date) = '" + Dates[num] + "' order by datetime";
            GeneralQuery(query, true);
            query = "";
            makeInsertion(datetime);
            KeepOpen = false;
        }

        static private void makeInsertion(string datetime)
        {
            string query;
            foreach (string row in General)
            {
                results.Add(row);
            }
            foreach(string insert in results)
            {
                query = "insert into " + temp + " (datetime, vdsId, lane, Speed, Occupancy, Volume) values ";
                query += " ( " + mergeDateandRecords(datetime, insert) + " )";
                GeneralQuery(query, false);
                query = "";
            }
            results.Clear();
            
        }

        static private string mergeDateandRecords(string datetime, string row)
        {
            string[] sep = { "," };
            string[] sep2 = { " " };
            string[] tokens = new string[6];
            string UTC;
            string[] date = new string[2];
            tokens = row.Split(sep, StringSplitOptions.None);
            UTC = System.Convert.ToDateTime(tokens[0]).ToString("yyyy-MM-dd HH:mm:ss") + ".000";
            date = UTC.Split(sep2, StringSplitOptions.None);
            return "'" + datetime + " " + date[1] + "', " + tokens[1] + ", " +
                tokens[2] + ", " + tokens[3] + ", " + tokens[4] + ", " + tokens[5];
        }

        static private string makeDate()
        {
            // startDate = { 2017, 01, 01 }           
            string[] sep = { "-", "-", "" };
            string dt = "";

            int i = 0;
            foreach (int num in startDate)
            {
                
                dt += dayMonth(num, i) + sep[i];
                i++;
            }
            incDate();
            return dt;
        }

        static private string dayMonth(int num, int i)
        {
            if((i != 0) && (num < 10))
            {
                return "0" + Convert.ToString(num);
            } else
            {
                return Convert.ToString(num);
            }
        }

        static private void incDate()
        {
            int maxMonth = getMaxMonth();
            startDate[2]++;
            if(startDate[2] > maxMonth)
            {
                startDate[2] = 1;
                startDate[1]++;
            }
            if(startDate[1] > 12)
            {
                startDate[1] = 1;
                startDate[0]++;
            }
            
        }

        static private int getMaxMonth()
        {
            int month = startDate[1];
            int maxMonth;
            switch(month)
            {
                case 2:
                    maxMonth = 28;
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    maxMonth = 30;
                    break;
                default:
                    maxMonth = 31;
                    break;
            }
            return maxMonth;
        }
    }
}