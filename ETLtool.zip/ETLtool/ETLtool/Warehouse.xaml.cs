﻿using System;
using System.Windows;

/*
     This is the Warehouse screen module.
     This module is the most complicated one.
     Although a shorter module, it is the behavior of it that gives way to the complexity.
     The main point of the ETL tool is to load data into a Warehouse table.
     However, even though there is expected to be a large amount of data to be transfered,
     it must be responsive to the user.
     Because of this requirement, this module is threaded. A background worker is used to
     carry out the task of querying the raw data tables, and loads it into the Warehouse.
     This functionality must be able to be inturrupted without causing the application to
     malfunction.
     This module must also constantly inform the user of what the background process is
     doing at all times.
*/

namespace ETLtool
{
    public partial class Warehouse : Window
    {
        public ETLController Controller;
        public MainWindow mainWin;

        private System.ComponentModel.BackgroundWorker worker;
        private int size;


        public Warehouse(ETLController mainController, MainWindow main)
        {
            InitializeComponent();
            mainWin = main;
            Controller = mainController;
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
            this.Closed += new EventHandler(Warehouse_Closed);
            worker = new System.ComponentModel.BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.DoWork += new System.ComponentModel.DoWorkEventHandler(execute);
            worker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(updateProgress);
            worker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(reset);
            worker.WorkerSupportsCancellation = true;
            Progress.Visibility = System.Windows.Visibility.Hidden;
            status.Visibility = System.Windows.Visibility.Hidden;
            status.Content = "    Indexing.";
        }

        void Warehouse_Closed(object sender, EventArgs e)
        {       
            if (worker.IsBusy)
            {
                MessageBox.Show("Canceling background process... please wait");        
                worker.CancelAsync();
                Progress.Value = 0;
                status.Content = "Cancelling, please wait...";
                MessageBox.Show("removing inserted records... please wait");
                Controller.erase();              
            }
            mainWin.Show();
        }

        private void hideDates()
        {
            LowDate.Visibility = System.Windows.Visibility.Hidden;
            HighDate.Visibility = System.Windows.Visibility.Hidden;
            Ok.IsEnabled = false;
            Progress.Visibility = System.Windows.Visibility.Visible;
            status.Visibility = System.Windows.Visibility.Visible;
            PickDate.Visibility = System.Windows.Visibility.Hidden;
            To.Visibility = System.Windows.Visibility.Hidden;
            From.Visibility = System.Windows.Visibility.Hidden;
            Cancel.IsEnabled = true;
        }

        private void showDates()
        {
            LowDate.Visibility = System.Windows.Visibility.Visible;
            HighDate.Visibility = System.Windows.Visibility.Visible;
            Ok.IsEnabled = true;
            Progress.Visibility = System.Windows.Visibility.Hidden;
            status.Visibility = System.Windows.Visibility.Hidden;
            PickDate.Visibility = System.Windows.Visibility.Visible;
            To.Visibility = System.Windows.Visibility.Visible;
            From.Visibility = System.Windows.Visibility.Visible;
            Progress.Value = 0;
            status.Content = "    Indexing.";
        }

        private void Ok_Click(object sender, RoutedEventArgs e)
        {
            if(HighDate.SelectedDate == null || LowDate.SelectedDate == null)
            {
                MessageBox.Show("You must select a high and low date.");
                return;
            } else if(HighDate.SelectedDate < LowDate.SelectedDate)
            {
                MessageBox.Show("End date must be after start date.");
                return;
            } else if(HighDate.SelectedDate > DateTime.Now.Date)
            {
                MessageBox.Show("End date cannot be in the future.");
                return;
            }
            if (!Controller.checkForWarhouse())
            {
                Controller.createWarehouseTable();
            }
            hideDates();
            TimeSpan difference = Convert.ToDateTime(HighDate.SelectedDate) - Convert.ToDateTime(LowDate.SelectedDate);
            if(difference.Days > 20)
            {
                MessageBox.Show("For larger stretches of time, the collection of information may take a few minutes... please wait...");
            }
            Cancel.IsEnabled = false;
            Cancel.Visibility = System.Windows.Visibility.Hidden;
            size = Controller.getTimeSpan(
                LowDate.SelectedDate.ToString(),
                formatHighDate(HighDate.SelectedDate.ToString())
                );
            Cancel.IsEnabled = true;
            Cancel.Visibility = System.Windows.Visibility.Visible;
            worker.RunWorkerAsync();
        }

        private void execute(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            if(size == 2)
            {
                Controller.transfer(1);
                return;
            } else if(size < 2)
            {
                return;
            }
            double temp = 0.0;
            double floatsize = Convert.ToDouble(size);
            string low = Controller.getLowDate();
            string high = Controller.getHighDate();

            int iterations = (size / 2016) + 1;
            int begin = 0;
            int end = 2016;
            for (int i = 0; i < iterations; i++)
            {
                if(begin >= size)
                {
                    break;
                } else if(end >= size)
                {
                    end = size;
                }
                if(Controller.checkDistance(begin, end))
                {
                    Controller.addTempIndex(begin, end);
                }          
                for (int j = begin + 1; j < end; j++)
                {
                    if (worker.CancellationPending)
                    {
                        worker.ReportProgress(-1);
                        e.Cancel = true;
                        return;
                    }
                    else
                    {
                        Controller.transfer(j);
                        temp = Convert.ToDouble(j) / floatsize * 100.0;
                        worker.ReportProgress(Convert.ToInt32(temp));
                    }
                }
                if (Controller.checkDistance(begin, end))
                {
                    Controller.dropTempIndex();
                }               
                begin = end;
                end = begin + 2016;
            }
        }

        private void updateProgress(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            if(e.ProgressPercentage < 0)
            {
            } else
            {
                Progress.Value = e.ProgressPercentage;
                status.Content = "Inserting... " + Convert.ToString(e.ProgressPercentage) + "% complete";
            }
        }

        private void reset(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            showDates();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            if (worker.IsBusy)
            {
                worker.CancelAsync();
                MessageBox.Show("Erasing inserted data... please wait");
                Progress.Value = 0;
                status.Content = "Cancelling, please wait...";
                Controller.erase();
                status.Content = "    Indexing.";
                showDates();
            } else
            {
                mainWin.Show();
                this.Close();
            }

        }

        private string formatHighDate(string highDate)
        {
            string[] sep = { " " };
            string[] splitted = highDate.Split(sep, StringSplitOptions.None);
            return splitted[0] + " 23:59:40.000";
        }
    }
}