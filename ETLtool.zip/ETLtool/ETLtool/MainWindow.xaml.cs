﻿using System.Windows;

/*
    This module contains the main splash screen of the ETL tool.
    If need be, it can be easily extended, and can keep the functionality
    given by the controller if it is passed in upon instantiation.
    All subpanes should be private, and be called only by the main window.
*/

namespace ETLtool
{
    public partial class MainWindow : Window
    {
        public ETLController Controller;

        public MainWindow()
        {        
            InitializeComponent();//           table     warehouse    server         database
            Controller = new ETLController("rawdataYear", "Warehouse55", "DESKTOP-TOSQMFB", "CMPT498");
            this.ResizeMode = System.Windows.ResizeMode.NoResize;
        }

        private void Warehouse_Click(object sender, RoutedEventArgs e)
        {
            Warehouse table = new Warehouse(Controller, this);
            table.Show();
            this.Hide();
        }

        private void Locations_Click(object sender, RoutedEventArgs e)
        {         
            locationTable table = new locationTable(Controller, this);
            table.Show();
            this.Hide();
        }
    }
}
